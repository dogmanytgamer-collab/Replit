const fs = require("node:fs");
const path = require("node:path");
const root = path.resolve(__dirname, "..");
const output = path.join(root, "dist");
fs.rmSync(output, { recursive: true, force: true });
fs.mkdirSync(output, { recursive: true });
for (const item of ["index.html", "css", "js"]) {
  fs.cpSync(path.join(root, item), path.join(output, item), { recursive: true });
}
console.log("Arquivos est?ticos preparados em dist/");
