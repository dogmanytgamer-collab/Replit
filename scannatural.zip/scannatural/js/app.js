import { api } from "./api.js";
import { parseFoodText, resizeItem, sumNutrition } from "./parser.js";
import { drawBars, drawDonut } from "./charts.js";

const $ = (selector, root) => (root || document).querySelector(selector);
const $$ = (selector, root) => Array.from((root || document).querySelectorAll(selector));
const authView = $("#authView"), appView = $("#appView");
const authForm = $("#authForm"), authError = $("#authError");
const dayPicker = $("#dayPicker");
let authMode = "login";
let verificationEmail = "";
let verificationName = "";
let currentUser = null;
let currentDay = localDay(new Date());
let goals = { kcal: 2000, protein: 100, carbs: 250, fat: 70 };
let entries = [];
let previewState = null;
let historyDays = 7;
let historyRows = [];
let toastTimer;
let chatMessages = [];
let selectedFoodPhoto = "";
let googleSignInPending = false;

function localDay(date) {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}
function number(value) {
  return Math.round(Number(value) || 0).toLocaleString("pt-BR");
}
function grams(value) {
  return (Math.round((Number(value) || 0) * 10) / 10).toLocaleString("pt-BR", { maximumFractionDigits: 1 });
}
function dateLabel(value, options) {
  const date = new Date(value + "T12:00:00");
  return new Intl.DateTimeFormat("pt-BR", options || { day: "numeric", month: "long", year: "numeric" }).format(date);
}
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 2800);
}
function setBusy(button, busy, label) {
  if (!button) return;
  button.disabled = busy;
  button.setAttribute("aria-busy", busy ? "true" : "false");
  if (label) button.textContent = busy ? label : button.dataset.originalLabel || button.textContent;
  if (label && !button.dataset.originalLabel) button.dataset.originalLabel = button.textContent;
}
function setAuthMode(mode) {
  authMode = mode;
  const isRegister = mode === "register";
  authForm.hidden = false;
  $(".auth-switch").hidden = false;
  $("#googleAuth").hidden = false;
  $("#verificationPanel").hidden = true;
  $("#nameWrap").hidden = !isRegister;
  $("#authName").required = isRegister;
  $("#authName").disabled = !isRegister;
  $("#authTitle").textContent = isRegister ? "Crie sua conta" : "Entre na sua conta";
  $("#authSubtitle").textContent = isRegister ? "Comece seu diário alimentar pessoal." : "Acesse seu diário alimentar pessoal.";
  $("#authSubmit").innerHTML = isRegister ? "Criar minha conta <span>→</span>" : "Entrar <span>→</span>";
  $$(".auth-switch__button").forEach((button) => {
    const active = button.dataset.authMode === mode;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-selected", active ? "true" : "false");
  });
  authError.hidden = true;
  authError.textContent = "";
  $("#verificationError").hidden = true;
  $("#verificationError").textContent = "";
}
function showAuth() {
  currentUser = null;
  appView.hidden = true;
  authView.hidden = false;
}
function showVerification(email, name) {
  verificationEmail = email;
  verificationName = name;
  $("#verificationEmail").textContent = email;
  $("#authTitle").textContent = "Confirme seu e-mail";
  $("#authSubtitle").textContent = "Digite o código para ativar sua conta.";
  authForm.hidden = true;
  $(".auth-switch").hidden = true;
  $("#googleAuth").hidden = true;
  $("#verificationPanel").hidden = false;
  $("#verificationError").hidden = true;
  $("#verificationCode").value = "";
  $("#verificationCode").focus();
}
async function showApp(user) {
  currentUser = user;
  authView.hidden = true;
  appView.hidden = false;
  $("#userName").textContent = user.name;
  $("#userInitial").textContent = Array.from(user.name.trim())[0]?.toUpperCase() || "S";
  $("#greeting").textContent = "Olá, " + user.name.split(/\s+/)[0] + ".";
  dayPicker.value = currentDay;
  await Promise.all([loadGoals(), loadDay()]);
  const activeView = $(".nav-button.is-active")?.dataset.view || "today";
  if (activeView === "progress") await loadHistory(historyDays);
}
function loadGoogleIdentitySdk() {
  if (window.google?.accounts?.id) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.defer = true;
    script.onload = resolve;
    script.onerror = () => reject(new Error("Não foi possível carregar o login do Google."));
    document.head.append(script);
  });
}
async function handleGoogleCredential(response) {
  const message = $("#googleAuthMessage");
  if (googleSignInPending) return;
  if (!response || !response.credential) {
    message.textContent = "O Google não retornou uma credencial. Tente novamente.";
    message.hidden = false;
    return;
  }
  googleSignInPending = true;
  message.hidden = true;
  try {
    const result = await api.post("/api/auth/google", { credential: response.credential });
    currentDay = localDay(new Date());
    await showApp(result.user);
  } catch (error) {
    message.textContent = error.message;
    message.hidden = false;
  } finally {
    googleSignInPending = false;
  }
}
async function setupGoogleSignIn() {
  try {
    const config = await api.get("/api/public-config");
    if (!config.googleClientId) {
      const hint = $("#googleSetupHint");
      hint.textContent = "Login Google não configurado no servidor. No Netlify, cadastre GOOGLE_CLIENT_ID em Site configuration > Environment variables, com escopo Production, e publique um novo deploy.";
      hint.hidden = false;
      return;
    }
    await loadGoogleIdentitySdk();
    const button = $("#googleSignInButton");
    $("#googleSignInPlaceholder").hidden = true;
    $("#googleSetupHint").hidden = true;
    window.google.accounts.id.initialize({
      client_id: config.googleClientId,
      callback: handleGoogleCredential,
      auto_select: false
    });
    window.google.accounts.id.renderButton(button, {
      type: "standard",
      theme: "outline",
      size: "large",
      text: "signin_with",
      shape: "rectangular",
      logo_alignment: "left",
      width: Math.min(320, Math.max(220, button.clientWidth || 320)),
      locale: "pt-BR"
    });
  } catch (error) {
    const message = $("#googleAuthMessage");
    message.textContent = error.status === 404
      ? "A rota da API de login não foi encontrada. Publique também as Netlify Functions e confira o redirecionamento /api/* no netlify.toml."
      : "Não foi possível iniciar o login com Google: " + error.message;
    message.hidden = false;
  }
}
function totalsForDay() {
  return sumNutrition(entries.flatMap((entry) => entry.items));
}
function renderMacros(totals) {
  const rows = [
    { key: "protein", label: "Proteínas", goal: goals.protein, color: "#47765d" },
    { key: "carbs", label: "Carboidratos", goal: goals.carbs, color: "#a8c875" },
    { key: "fat", label: "Gorduras", goal: goals.fat, color: "#e3aa72" }
  ];
  const container = $("#macroRows");
  container.replaceChildren();
  rows.forEach((row) => {
    const item = document.createElement("div");
    const heading = document.createElement("div");
    heading.className = "macro-row__heading";
    const label = document.createElement("span");
    label.textContent = row.label;
    const value = document.createElement("span");
    value.textContent = grams(totals[row.key]) + " / " + number(row.goal) + " g";
    heading.append(label, value);
    const track = document.createElement("div");
    track.className = "macro-track";
    const fill = document.createElement("span");
    fill.style.setProperty("--fill", row.color);
    fill.style.width = Math.min(100, row.goal ? totals[row.key] / row.goal * 100 : 0) + "%";
    track.append(fill);
    item.append(heading, track);
    container.append(item);
  });
  const micro = [
    ["Fibras", totals.fiber, "g"],
    ["Açúcares", totals.sugar, "g"],
    ["Sódio", totals.sodium, "mg"]
  ];
  const microContainer = $("#microSummary");
  microContainer.replaceChildren();
  micro.forEach(([label, value, unit]) => {
    const chip = document.createElement("span");
    chip.className = "micro-chip";
    const strong = document.createElement("strong");
    strong.textContent = grams(value) + " " + unit;
    chip.append(document.createTextNode(label + " "), strong);
    microContainer.append(chip);
  });
}
function renderSummary() {
  const totals = totalsForDay();
  const progress = goals.kcal ? Math.min(1, totals.kcal / goals.kcal) : 0;
  $("#kcalValue").textContent = number(totals.kcal);
  $("#kcalRemaining").textContent = number(goals.kcal);
  $("#calorieRing").style.setProperty("--degree", (progress * 360) + "deg");
  $("#calorieRing").setAttribute("aria-label", number(totals.kcal) + " kcal registradas, referência de " + number(goals.kcal) + " kcal");
  $("#kcalSubtext").textContent = totals.kcal ? "Estimativa conforme seus registros." : "Comece registrando uma refeição.";
  renderMacros(totals);
  drawDonut($("#macroDonut"), totals, $("#macroLegend"));
}
function makeFoodEntry(entry) {
  const article = document.createElement("article");
  article.className = "food-entry";
  const top = document.createElement("div");
  top.className = "food-entry__top";
  const title = document.createElement("strong");
  title.textContent = number(entry.totals.kcal) + " kcal";
  const macros = document.createElement("span");
  macros.textContent = "P " + grams(entry.totals.protein) + " · C " + grams(entry.totals.carbs) + " · G " + grams(entry.totals.fat) + " g";
  top.append(title, macros);
  const itemNames = document.createElement("div");
  itemNames.className = "food-entry__items";
  itemNames.textContent = entry.items.map((item) => item.name + " (" + item.grams + " g)").join(", ");
  const remove = document.createElement("button");
  remove.type = "button";
  remove.className = "remove-entry";
  remove.textContent = "Remover registro";
  remove.addEventListener("click", async () => {
    remove.disabled = true;
    try {
      await api.delete("/api/entries/" + encodeURIComponent(entry.id));
      await loadDay();
      showToast("Registro removido.");
    } catch (error) {
      showToast(error.message);
      remove.disabled = false;
    }
  });
  article.append(top, itemNames, remove);
  return article;
}
function renderMealList() {
  const root = $("#mealList");
  root.replaceChildren();
  $("#entryCount").textContent = String(entries.length);
  if (!entries.length) {
    const empty = document.createElement("div");
    empty.className = "meal-empty";
    empty.textContent = "Ainda não há refeições neste dia. Seus registros aparecerão aqui.";
    root.append(empty);
    return;
  }
  const order = ["Café da manhã", "Almoço", "Lanche", "Jantar", "Outro"];
  order.forEach((meal) => {
    const groupEntries = entries.filter((entry) => entry.meal === meal);
    if (!groupEntries.length) return;
    const group = document.createElement("section");
    group.className = "meal-group";
    const heading = document.createElement("div");
    heading.className = "meal-group__heading";
    const name = document.createElement("strong");
    name.textContent = meal;
    const calories = groupEntries.reduce((sum, entry) => sum + entry.totals.kcal, 0);
    const total = document.createElement("span");
    total.textContent = number(calories) + " kcal";
    heading.append(name, total);
    group.append(heading);
    groupEntries.forEach((entry) => group.append(makeFoodEntry(entry)));
    root.append(group);
  });
}
async function loadDay() {
  try {
    const response = await api.get("/api/entries?day=" + encodeURIComponent(currentDay));
    entries = response.entries;
    renderMealList();
    renderSummary();
    $("#dayPicker").value = currentDay;
    $("#dayPicker").setAttribute("aria-label", "Dia " + dateLabel(currentDay));
  } catch (error) {
    showToast(error.message);
    if (error.status === 401) showAuth();
  }
}
async function loadGoals() {
  const response = await api.get("/api/goals");
  goals = response.goals;
  const form = $("#goalsForm");
  Object.entries(goals).forEach(([key, value]) => {
    const field = form.elements.namedItem(key);
    if (field) field.value = Math.round(value);
  });
  renderSummary();
}
function renderPreview() {
  if (!previewState) return;
  const root = $("#previewItems");
  root.replaceChildren();
  previewState.items.forEach((item, index) => {
    const row = document.createElement("div");
    row.className = "preview-item";
    const label = document.createElement("div");
    const name = document.createElement("strong");
    name.textContent = item.name;
    const details = document.createElement("small");
    details.textContent = number(item.nutrients.kcal) + " kcal estimadas";
    label.append(name, details);
    const input = document.createElement("input");
    input.type = "number";
    input.min = "1";
    input.max = "10000";
    input.step = "1";
    input.value = String(item.grams);
    input.setAttribute("aria-label", "Quantidade em gramas de " + item.name);
    input.addEventListener("change", () => {
      if (!input.value || Number(input.value) < 1) return;
      previewState.items[index] = resizeItem(item, input.value);
      renderPreview();
    });
    row.append(label, input);
    root.append(row);
  });
  const totals = sumNutrition(previewState.items);
  $("#previewKcal").textContent = number(totals.kcal) + " kcal";
  const unknown = $("#unknownNote");
  if (previewState.unknown.length) {
    unknown.hidden = false;
    unknown.textContent = "Não reconheci: " + previewState.unknown.join(", ") + ". Confira a base disponível antes de salvar.";
  } else {
    unknown.hidden = true;
  }
  $("#saveEntry").disabled = previewState.items.length === 0;
}
function clearPreview() {
  previewState = null;
  $("#preview").hidden = true;
}
function renderHistoryStats(rows) {
  const root = $("#historyStats");
  root.replaceChildren();
  const sum = rows.reduce((acc, row) => acc + row.kcal, 0);
  const recorded = rows.filter((row) => row.kcal > 0);
  const average = rows.length ? Math.round(sum / rows.length) : 0;
  const highest = rows.reduce((max, row) => Math.max(max, row.kcal), 0);
  [
    ["Média diária", number(average) + " kcal"],
    ["Dias com registros", recorded.length + " de " + rows.length],
    ["Maior total registrado", number(highest) + " kcal"]
  ].forEach(([label, value]) => {
    const card = document.createElement("article");
    card.className = "stat-card";
    const caption = document.createElement("span");
    caption.textContent = label;
    const amount = document.createElement("strong");
    amount.textContent = value;
    card.append(caption, amount);
    root.append(card);
  });
}
async function loadHistory(days) {
  historyDays = days;
  try {
    const response = await api.get("/api/history?days=" + days + "&end=" + encodeURIComponent(currentDay));
    historyRows = response.history;
    drawBars($("#historyChart"), historyRows, goals.kcal);
    renderHistoryStats(historyRows);
  } catch (error) {
    showToast(error.message);
  }
}
async function compressFoodPhoto(file) {
  if (file.type && !file.type.startsWith("image/")) throw new Error("Escolha um arquivo de imagem.");
  if (file.size > 12 * 1024 * 1024) throw new Error("A foto precisa ter menos de 12 MB.");
  let source;
  if (typeof createImageBitmap === "function") {
    try { source = await createImageBitmap(file); } catch { /* tenta a decodificação compatível abaixo */ }
  }
  if (!source) {
    const url = URL.createObjectURL(file);
    try {
      const image = await new Promise((resolve, reject) => {
        const element = new Image();
        element.onload = () => resolve(element);
        element.onerror = () => reject(new Error("Não foi possível abrir essa imagem. Use uma foto JPG, PNG ou WebP."));
        element.src = url;
      });
      source = {
        width: image.naturalWidth,
        height: image.naturalHeight,
        draw: (context, width, height) => context.drawImage(image, 0, 0, width, height),
        close: () => URL.revokeObjectURL(url)
      };
    } catch (error) {
      URL.revokeObjectURL(url);
      throw error;
    }
  }
  if (!source.width || !source.height) {
    source.close?.();
    throw new Error("Não foi possível ler as dimensões da foto. Escolha outra imagem.");
  }
  const scale = Math.min(1, 1280 / Math.max(source.width, source.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(source.width * scale));
  canvas.height = Math.max(1, Math.round(source.height * scale));
  const context = canvas.getContext("2d", { alpha: false });
  if (!context) {
    source.close?.();
    throw new Error("Não foi possível preparar a foto neste navegador.");
  }
  try { source.draw ? source.draw(context, canvas.width, canvas.height) : context.drawImage(source, 0, 0, canvas.width, canvas.height); }
  finally { source.close?.(); }
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.82));
  if (!blob || blob.size > 3 * 1024 * 1024) throw new Error("Não foi possível reduzir a foto. Escolha outra imagem.");
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Não foi possível ler essa foto."));
    reader.readAsDataURL(blob);
  });
}
async function handleFoodPhoto(event) {
  const input = event.currentTarget;
  const file = input.files?.[0];
  input.value = "";
  if (!file) return;
  const button = $("#analyzePhotoButton");
  const error = $("#photoError");
  error.hidden = true;
  button.disabled = true;
  button.textContent = "Preparando foto...";
  try {
    selectedFoodPhoto = await compressFoodPhoto(file);
    $("#photoImage").src = selectedFoodPhoto;
    $("#photoPreview").hidden = false;
    $("#photoResult").hidden = true;
    button.innerHTML = "Identificar alimento <span>→</span>";
    button.disabled = false;
  } catch (photoError) {
    selectedFoodPhoto = "";
    error.textContent = photoError.message;
    error.hidden = false;
    button.innerHTML = "Identificar alimento <span>→</span>";
    button.disabled = true;
  }
}
function appendChatMessage(role, content) {
  const root = $("#chatLog");
  const message = document.createElement("div");
  message.className = "chat-message chat-message--" + role;
  const label = document.createElement("span");
  label.className = "chat-message__label";
  label.textContent = role === "user" ? "Você" : "ScanNatural";
  const text = document.createElement("p");
  text.textContent = content;
  message.append(label, text);
  root.append(message);
  root.scrollTop = root.scrollHeight;
  return message;
}
function resetChat() {
  chatMessages = [];
  const root = $("#chatLog");
  root.replaceChildren();
  appendChatMessage("assistant", "Oi! Posso explicar nutrientes, alimentos e hábitos de forma geral. O que você gostaria de saber?");
}
async function sendChatQuestion(value) {
  const question = String(value || "").trim();
  if (!question || $("#chatSubmit").disabled) return;
  chatMessages.push({ role: "user", content: question });
  appendChatMessage("user", question);
  $("#chatInput").value = "";
  $("#chatSubmit").disabled = true;
  const pending = appendChatMessage("assistant", "Pensando...");
  try {
    const response = await api.post("/api/assistant/chat", { messages: chatMessages.slice(-10) });
    pending.querySelector("p").textContent = response.reply;
    chatMessages.push({ role: "assistant", content: response.reply });
    chatMessages = chatMessages.slice(-10);
  } catch (error) {
    pending.querySelector("p").textContent = error.message;
  } finally {
    $("#chatSubmit").disabled = false;
    $("#chatInput").focus();
  }
}
function showView(view) {
  $$(".view").forEach((section) => { section.hidden = section.id !== "view-" + view; });
  $$(".nav-button").forEach((button) => button.classList.toggle("is-active", button.dataset.view === view));
  if (view === "progress") loadHistory(historyDays);
}
function moveDate(amount) {
  const date = new Date(currentDay + "T12:00:00");
  date.setDate(date.getDate() + amount);
  currentDay = localDay(date);
  loadDay();
}

$$(".auth-switch__button").forEach((button) => button.addEventListener("click", () => setAuthMode(button.dataset.authMode)));
$$("[data-chat-prompt]").forEach((button) => button.addEventListener("click", () => sendChatQuestion(button.dataset.chatPrompt)));
$("#chatForm").addEventListener("submit", (event) => {
  event.preventDefault();
  sendChatQuestion($("#chatInput").value);
});
$("#foodPhotoCamera").addEventListener("change", handleFoodPhoto);
$("#foodPhotoGallery").addEventListener("change", handleFoodPhoto);
$("#removePhotoButton").addEventListener("click", () => {
  selectedFoodPhoto = "";
  $("#photoImage").removeAttribute("src");
  $("#photoPreview").hidden = true;
  $("#photoResult").hidden = true;
  $("#analyzePhotoButton").disabled = true;
  $("#photoError").hidden = true;
});
$("#analyzePhotoButton").addEventListener("click", async (event) => {
  if (!selectedFoodPhoto) return;
  const button = event.currentTarget;
  const error = $("#photoError");
  error.hidden = true;
  button.disabled = true;
  button.textContent = "Analisando foto...";
  try {
    const response = await api.post("/api/assistant/analyze-food-photo", {
      imageDataUrl: selectedFoodPhoto,
      portion: $("#photoPortion").value.trim(),
      meal: $("#mealSelect").value
    });
    const estimate = response.estimate;
    const confidence = { high: "Boa confiança", medium: "Confiança média", low: "Baixa confiança" };
    $("#photoFoodName").textContent = estimate.is_food ? estimate.food_name : "Não identifiquei um alimento";
    $("#photoPortionResult").textContent = estimate.is_food ? "Porção visual estimada: " + estimate.portion_estimate : "";
    $("#photoCalories").textContent = estimate.is_food ? number(estimate.calories_min) + "–" + number(estimate.calories_max) + " kcal" : "Faixa de calorias indisponível";
    $("#photoConfidence").textContent = confidence[estimate.confidence] || "Estimativa";
    $("#photoNote").textContent = estimate.note;
    $("#photoResult").hidden = false;
  } catch (photoError) {
    error.textContent = photoError.message;
    error.hidden = false;
  } finally {
    button.innerHTML = "Identificar alimento <span>→</span>";
    button.disabled = !selectedFoodPhoto;
  }
});
authForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  authError.hidden = true;
  const data = new FormData(authForm);
  const button = $("#authSubmit");
  button.disabled = true;
  try {
    const endpoint = authMode === "register" ? "/api/auth/register" : "/api/auth/login";
    const submittedName = String(data.get("name") || "").trim();
    const submittedEmail = String(data.get("email") || "").trim().toLowerCase();
    const response = await api.post(endpoint, {
      name: submittedName,
      email: submittedEmail,
      password: data.get("password")
    });
    if (response.verificationRequired) {
      authForm.reset();
      showVerification(response.email, submittedName);
      return;
    }
    authForm.reset();
    currentDay = localDay(new Date());
    await showApp(response.user);
  } catch (error) {
    authError.textContent = error.message;
    authError.hidden = false;
  } finally {
    button.disabled = false;
  }
});
$("#verificationForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = $("#verifySubmit");
  const errorNode = $("#verificationError");
  errorNode.hidden = true;
  button.disabled = true;
  try {
    const response = await api.post("/api/auth/verify-email", { email: verificationEmail, code: $("#verificationCode").value.trim() });
    currentDay = localDay(new Date());
    await showApp(response.user);
    showToast("E-mail confirmado. Sua conta está pronta.");
  } catch (error) {
    errorNode.textContent = error.message;
    errorNode.hidden = false;
  } finally {
    button.disabled = false;
  }
});
$("#resendCodeButton").addEventListener("click", async (event) => {
  const button = event.currentTarget;
  const errorNode = $("#verificationError");
  errorNode.hidden = true;
  button.disabled = true;
  try {
    await api.post("/api/auth/resend-code", { email: verificationEmail });
    showToast("Enviamos um novo código para seu e-mail.");
  } catch (error) {
    errorNode.textContent = error.message;
    errorNode.hidden = false;
  } finally {
    button.disabled = false;
  }
});
$("#editRegistrationButton").addEventListener("click", () => {
  $("#verificationPanel").hidden = true;
  authForm.hidden = false;
  $(".auth-switch").hidden = false;
  setAuthMode("register");
  authForm.elements.namedItem("name").value = verificationName;
  authForm.elements.namedItem("email").value = verificationEmail;
  authForm.elements.namedItem("password").focus();
});
$$(".nav-button").forEach((button) => button.addEventListener("click", () => showView(button.dataset.view)));
$("#logoutButton").addEventListener("click", async () => {
  try { await api.post("/api/auth/logout"); } catch (error) { showToast(error.message); }
  resetChat();
  showAuth();
  setAuthMode("login");
});
$("#prevDate").addEventListener("click", () => moveDate(-1));
$("#nextDate").addEventListener("click", () => moveDate(1));
dayPicker.addEventListener("change", () => {
  if (!dayPicker.value) return;
  currentDay = dayPicker.value;
  loadDay();
});
$("#foodForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const parsed = parseFoodText($("#foodInput").value);
  if (!parsed.items.length) {
    showToast("Não encontrei alimentos conhecidos nessa descrição.");
    return;
  }
  previewState = parsed;
  $("#preview").hidden = false;
  renderPreview();
});
$("#cancelPreview").addEventListener("click", clearPreview);
$("#saveEntry").addEventListener("click", async () => {
  if (!previewState || !previewState.items.length) return;
  const button = $("#saveEntry");
  button.disabled = true;
  try {
    await api.post("/api/entries", {
      day: currentDay,
      meal: $("#mealSelect").value,
      items: previewState.items.map((item) => ({ id: crypto.randomUUID(), name: item.name, grams: item.grams, nutrients: item.nutrients }))
    });
    $("#foodInput").value = "";
    clearPreview();
    await loadDay();
    showToast("Refeição adicionada ao diário.");
  } catch (error) {
    showToast(error.message);
    button.disabled = false;
  }
});
$("#goalsForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  const values = Object.fromEntries(["kcal", "protein", "carbs", "fat"].map((key) => [key, Number(data.get(key))]));
  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  try {
    const response = await api.put("/api/goals", values);
    goals = response.goals;
    renderSummary();
    if (historyRows.length) drawBars($("#historyChart"), historyRows, goals.kcal);
    $("#goalSaved").hidden = false;
    setTimeout(() => { $("#goalSaved").hidden = true; }, 2500);
    showToast("Metas atualizadas.");
  } catch (error) { showToast(error.message); }
  finally { button.disabled = false; }
});
$$("[data-range]").forEach((button) => button.addEventListener("click", () => {
  $$("[data-range]").forEach((item) => item.classList.toggle("is-active", item === button));
  loadHistory(Number(button.dataset.range));
}));
window.addEventListener("resize", () => {
  if (!appView.hidden) {
    drawDonut($("#macroDonut"), totalsForDay(), $("#macroLegend"));
    if (historyRows.length) drawBars($("#historyChart"), historyRows, goals.kcal);
  }
});

async function init() {
  setAuthMode("login");
  dayPicker.value = currentDay;
  void setupGoogleSignIn();
  try {
    const response = await api.get("/api/auth/me");
    if (response.user) await showApp(response.user);
    else showAuth();
  } catch {
    showAuth();
    authError.textContent = "Não foi possível conectar ao servidor. Confira se ele está iniciado e recarregue a página.";
    authError.hidden = false;
  }
}
init();
