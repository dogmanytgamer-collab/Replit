export const foods = [
  { id: "rice", name: "Arroz cozido", aliases: ["arroz", "arroz branco", "arroz cozido"], portion: 150, counted: false, kcal: 128, protein: 2.5, carbs: 28.1, fat: 0.2, fiber: 1.6, sugar: 0.1, sodium: 1 },
  { id: "beans", name: "Feijão cozido", aliases: ["feijão", "feijao", "feijão carioca", "feijão preto", "feijao preto"], portion: 130, counted: false, kcal: 76, protein: 4.8, carbs: 13.6, fat: 0.5, fiber: 8.5, sugar: 0.3, sodium: 2 },
  { id: "chicken", name: "Frango grelhado", aliases: ["frango grelhado", "peito de frango", "frango"], portion: 120, counted: false, kcal: 159, protein: 32, carbs: 0, fat: 2.5, fiber: 0, sugar: 0, sodium: 50 },
  { id: "egg", name: "Ovo cozido", aliases: ["ovo cozido", "ovos cozidos", "ovo", "ovos"], portion: 50, counted: true, kcal: 155, protein: 13, carbs: 1.1, fat: 10.6, fiber: 0, sugar: 1.1, sodium: 124 },
  { id: "banana", name: "Banana", aliases: ["banana", "bananas"], portion: 90, counted: true, kcal: 89, protein: 1.1, carbs: 22.8, fat: 0.3, fiber: 2.6, sugar: 12.2, sodium: 1 },
  { id: "apple", name: "Maçã", aliases: ["maçã", "maca", "maçãs", "macas"], portion: 160, counted: true, kcal: 52, protein: 0.3, carbs: 13.8, fat: 0.2, fiber: 2.4, sugar: 10.4, sodium: 1 },
  { id: "oats", name: "Aveia", aliases: ["aveia", "aveia em flocos"], portion: 30, counted: false, kcal: 389, protein: 16.9, carbs: 66.3, fat: 6.9, fiber: 10.6, sugar: 0.9, sodium: 2 },
  { id: "milk", name: "Leite integral", aliases: ["leite integral", "leite"], portion: 240, counted: false, kcal: 61, protein: 3.2, carbs: 4.7, fat: 3.3, fiber: 0, sugar: 5, sodium: 44 },
  { id: "bread", name: "Pão integral", aliases: ["pão integral", "pao integral", "pão francês", "pao frances", "pão", "pao"], portion: 50, counted: false, kcal: 247, protein: 13, carbs: 41, fat: 4.2, fiber: 7, sugar: 6, sodium: 450 },
  { id: "cheese", name: "Queijo minas", aliases: ["queijo minas", "queijo"], portion: 30, counted: false, kcal: 264, protein: 17.4, carbs: 3.2, fat: 20, fiber: 0, sugar: 0.5, sodium: 290 },
  { id: "tapioca", name: "Tapioca preparada", aliases: ["tapioca", "goma de tapioca"], portion: 60, counted: false, kcal: 130, protein: 0.2, carbs: 32, fat: 0.1, fiber: 0.2, sugar: 0.5, sodium: 1 },
  { id: "tomato", name: "Tomate", aliases: ["tomate", "tomates"], portion: 100, counted: false, kcal: 18, protein: 0.9, carbs: 3.9, fat: 0.2, fiber: 1.2, sugar: 2.6, sodium: 5 },
  { id: "lettuce", name: "Alface", aliases: ["alface"], portion: 50, counted: false, kcal: 15, protein: 1.4, carbs: 2.9, fat: 0.2, fiber: 1.3, sugar: 0.8, sodium: 28 },
  { id: "sweet-potato", name: "Batata-doce cozida", aliases: ["batata doce", "batata-doce"], portion: 130, counted: false, kcal: 86, protein: 1.6, carbs: 20.1, fat: 0.1, fiber: 3, sugar: 4.2, sodium: 5 },
  { id: "pasta", name: "Macarrão cozido", aliases: ["macarrão", "macarrao", "macarrão cozido", "macarrao cozido"], portion: 150, counted: false, kcal: 157, protein: 5.8, carbs: 30.9, fat: 0.9, fiber: 1.8, sugar: 0.6, sodium: 1 },
  { id: "beef", name: "Carne bovina grelhada", aliases: ["carne bovina", "carne moída", "carne moida", "carne"], portion: 100, counted: false, kcal: 217, protein: 26, carbs: 0, fat: 12, fiber: 0, sugar: 0, sodium: 65 },
  { id: "yogurt", name: "Iogurte natural", aliases: ["iogurte natural", "iogurte"], portion: 170, counted: false, kcal: 63, protein: 5.3, carbs: 7, fat: 1.6, fiber: 0, sugar: 7, sodium: 70 },
  { id: "orange", name: "Laranja", aliases: ["laranja", "laranjas"], portion: 130, counted: true, kcal: 47, protein: 0.9, carbs: 11.8, fat: 0.1, fiber: 2.4, sugar: 9.4, sodium: 0 },
  { id: "olive-oil", name: "Azeite", aliases: ["azeite", "azeite de oliva"], portion: 5, counted: false, kcal: 884, protein: 0, carbs: 0, fat: 100, fiber: 0, sugar: 0, sodium: 2 },
  { id: "avocado", name: "Abacate", aliases: ["abacate"], portion: 100, counted: false, kcal: 160, protein: 2, carbs: 8.5, fat: 14.7, fiber: 6.7, sugar: 0.7, sodium: 7 },
  { id: "salmon", name: "Salmão grelhado", aliases: ["salmão", "salmao"], portion: 100, counted: false, kcal: 206, protein: 22, carbs: 0, fat: 12.4, fiber: 0, sugar: 0, sodium: 59 }
];
export const foodById = Object.fromEntries(foods.map((food) => [food.id, food]));
