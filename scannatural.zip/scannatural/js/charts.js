function colors() {
  const style = getComputedStyle(document.documentElement);
  return { green: style.getPropertyValue("--green-2").trim(), mint: style.getPropertyValue("--mint").trim(), muted: style.getPropertyValue("--muted").trim(), line: style.getPropertyValue("--line").trim(), card: style.getPropertyValue("--card").trim(), ink: style.getPropertyValue("--ink").trim() };
}
function setup(canvas) {
  const rect = canvas.getBoundingClientRect();
  const scale = window.devicePixelRatio || 1;
  canvas.width = Math.max(1, rect.width * scale);
  canvas.height = Math.max(1, rect.height * scale);
  const ctx = canvas.getContext("2d");
  ctx.scale(scale, scale);
  return { ctx, width: rect.width, height: rect.height };
}
export function drawDonut(canvas, totals, legend) {
  const { ctx, width, height } = setup(canvas);
  const color = colors();
  const values = [totals.protein * 4, totals.carbs * 4, totals.fat * 9];
  const labels = ["Proteínas", "Carboidratos", "Gorduras"];
  const fills = [color.green, "#a8c875", "#e3aa72"];
  const total = values.reduce((sum, value) => sum + value, 0);
  ctx.clearRect(0, 0, width, height);
  const cx = width / 2, cy = height / 2, radius = Math.min(width, height) * .36;
  if (!total) {
    ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.strokeStyle = color.mint; ctx.lineWidth = 19; ctx.stroke();
  } else {
    let start = -Math.PI / 2;
    values.forEach((value, index) => {
      const end = start + value / total * Math.PI * 2;
      ctx.beginPath(); ctx.arc(cx, cy, radius, start, end); ctx.strokeStyle = fills[index]; ctx.lineWidth = 19; ctx.lineCap = "butt"; ctx.stroke(); start = end;
    });
  }
  ctx.fillStyle = color.ink; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.font = "700 16px Manrope, sans-serif"; ctx.fillText(total ? Math.round(total) + " kcal" : "Sem dados", cx, cy);
  legend.replaceChildren();
  labels.forEach((label, index) => {
    const li = document.createElement("li"), swatch = document.createElement("i"), text = document.createElement("span");
    swatch.style.setProperty("--fill", fills[index]);
    const share = total ? Math.round(values[index] / total * 100) : 0;
    text.textContent = label + " · " + share + "%";
    li.append(swatch, text); legend.append(li);
  });
}
export function drawBars(canvas, rows, goal) {
  const { ctx, width, height } = setup(canvas);
  const color = colors();
  ctx.clearRect(0, 0, width, height);
  const pad = { top: 18, right: 12, bottom: 30, left: 44 };
  const chartW = width - pad.left - pad.right, chartH = height - pad.top - pad.bottom;
  const maxValue = Math.max(goal || 0, ...rows.map((row) => row.kcal), 500) * 1.16;
  ctx.font = "11px DM Sans, sans-serif"; ctx.textBaseline = "middle";
  for (let i = 0; i <= 4; i += 1) {
    const y = pad.top + chartH * i / 4;
    ctx.strokeStyle = color.line; ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(width - pad.right, y); ctx.stroke();
    ctx.fillStyle = color.muted; ctx.textAlign = "right"; ctx.fillText(Math.round(maxValue * (1 - i / 4)), pad.left - 8, y);
  }
  if (goal > 0) {
    const y = pad.top + chartH * (1 - goal / maxValue);
    ctx.save(); ctx.setLineDash([5, 5]); ctx.strokeStyle = color.green; ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(width - pad.right, y); ctx.stroke(); ctx.restore();
  }
  const slot = chartW / Math.max(rows.length, 1), barW = Math.max(4, Math.min(25, slot * .52));
  rows.forEach((row, index) => {
    const value = Math.max(0, row.kcal);
    const barH = value / maxValue * chartH;
    const x = pad.left + slot * index + (slot - barW) / 2;
    const y = pad.top + chartH - barH;
    ctx.fillStyle = value > goal ? "#dc945b" : color.green;
    const radius = Math.min(5, barW / 2);
    ctx.beginPath(); ctx.roundRect(x, y, barW, barH, [radius, radius, 0, 0]); ctx.fill();
    if (rows.length <= 14 || index % 5 === 0 || index === rows.length - 1) {
      ctx.fillStyle = color.muted; ctx.textAlign = "center";
      const date = new Date(row.day + "T12:00:00");
      ctx.fillText(date.getDate() + "/" + (date.getMonth() + 1), x + barW / 2, height - 11);
    }
  });
}
