import { foods, foodById } from "./foods.js";

export function normalize(value) {
  return String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
}
const searchable = foods.flatMap((food) => food.aliases.map((alias) => ({ food, alias: normalize(alias) })).sort((a, b) => b.alias.length - a.alias.length));
function findFood(text) {
  const value = normalize(text);
  return searchable.find((item) => value === item.alias || value.includes(item.alias))?.food || null;
}
export function nutritionFor(food, grams) {
  const result = {};
  for (const key of ["kcal", "protein", "carbs", "fat", "fiber", "sugar", "sodium"]) {
    result[key] = Math.round(food[key] * grams / 100 * 10) / 10;
  }
  return result;
}
function parsePart(part) {
  const quantity = part.match(/^(\d+(?:[.,]\d+)?)\s*(.*)$/);
  const amount = quantity ? Number(quantity[1].replace(",", ".")) : 1;
  let rest = quantity ? quantity[2].trim() : part.trim();
  let measure = "";
  const measureMatch = rest.match(/^(kg|gramas?|gr|g|ml|unidades?|un|fatias?|fatia|conchas?|concha|copos?|copo|colheres?(?:\s+de\s+sopa)?|pratos?|prato)\b\s*(?:de\s+)?(.*)$/);
  if (measureMatch) {
    measure = normalize(measureMatch[1]);
    rest = measureMatch[2].trim();
  } else {
    rest = rest.replace(/^(?:de|do|da|dos|das)\s+/, "");
  }
  const food = findFood(rest);
  if (!food) return null;
  let grams;
  if (measure === "kg") grams = amount * 1000;
  else if (measure === "g" || measure === "gr" || measure.startsWith("grama")) grams = amount;
  else if (measure === "ml") grams = amount;
  else if (measure.startsWith("colher")) grams = amount * 15;
  else if (measure.startsWith("concha")) grams = amount * 130;
  else if (measure.startsWith("copo")) grams = amount * 240;
  else if (measure.startsWith("fatia")) grams = amount * 30;
  else if (measure.startsWith("prato")) grams = amount * 300;
  else if (measure === "un" || measure.startsWith("unidade")) grams = amount * food.portion;
  else if (!quantity) grams = 100;
  else grams = amount * (food.counted ? food.portion : 100);
  grams = Math.max(1, Math.round(grams));
  return { foodId: food.id, name: food.name, grams, nutrients: nutritionFor(food, grams) };
}
export function parseFoodText(text) {
  const parts = String(text || "").replace(/\s+e\s+/gi, ",").split(/[,;\n]+/).map((part) => part.trim()).filter(Boolean);
  const items = [], unknown = [];
  for (const part of parts) {
    const item = parsePart(part);
    if (item) items.push(item);
    else unknown.push(part);
  }
  return { items, unknown };
}
export function resizeItem(item, grams) {
  const food = foodById[item.foodId];
  if (!food) return item;
  const amount = Math.max(1, Math.min(10000, Math.round(Number(grams) || 1)));
  return Object.assign({}, item, { grams: amount, nutrients: nutritionFor(food, amount) });
}
export function sumNutrition(items) {
  const total = { kcal: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, sugar: 0, sodium: 0 };
  for (const item of items) for (const key of Object.keys(total)) total[key] += item.nutrients[key] || 0;
  for (const key of Object.keys(total)) total[key] = Math.round(total[key] * 10) / 10;
  return total;
}
