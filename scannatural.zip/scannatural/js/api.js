async function request(path, options) {
  const config = options || {};
  const headers = Object.assign({ "Content-Type": "application/json" }, config.headers || {});
  const response = await fetch(path, Object.assign({ credentials: "same-origin" }, config, { headers }));
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || "Não foi possível concluir essa ação.");
    error.status = response.status;
    throw error;
  }
  return data;
}
export const api = {
  get: (path) => request(path),
  post: (path, body) => request(path, { method: "POST", body: JSON.stringify(body || {}) }),
  put: (path, body) => request(path, { method: "PUT", body: JSON.stringify(body || {}) }),
  delete: (path) => request(path, { method: "DELETE" })
};
