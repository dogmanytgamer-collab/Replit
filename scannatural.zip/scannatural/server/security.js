const crypto = require("node:crypto");
const { promisify } = require("node:util");
const scrypt = promisify(crypto.scrypt);
const store = require("./database");

const sha256 = (value) => crypto.createHash("sha256").update(value).digest("hex");
async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = await scrypt(password, salt, 64, { N: 16384, r: 8, p: 1 });
  return "scrypt$" + salt + "$" + hash.toString("hex");
}
async function verifyPassword(password, saved) {
  const parts = String(saved || "").split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;
  const expected = Buffer.from(parts[2], "hex");
  if (expected.length !== 64) return false;
  const actual = await scrypt(password, parts[1], 64, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(expected, actual);
}
function readCookie(req) {
  for (const part of String(req.headers.cookie || "").split(";")) {
    const item = part.trim();
    if (item.startsWith("sn_session=")) return decodeURIComponent(item.slice(11));
  }
  return "";
}
function setCookie(res, token, clear) {
  const flags = ["sn_session=" + (clear ? "" : encodeURIComponent(token)), "Path=/", "HttpOnly", "SameSite=Lax", "Max-Age=" + (clear ? 0 : 604800)];
  if (process.env.NODE_ENV === "production" || process.env.NETLIFY === "true") flags.push("Secure");
  res.setHeader("Set-Cookie", flags.join("; "));
}
async function createSession(userId, res) {
  const token = crypto.randomBytes(32).toString("base64url");
  await store.createSession(sha256(token), userId, new Date(Date.now() + 7 * 86400000).toISOString());
  setCookie(res, token, false);
}
async function attachUser(req, res, next) {
  try {
    const token = readCookie(req);
    const session = token ? await store.findSession(sha256(token)) : null;
    req.user = session ? await store.findUserById(session.user_id) : null;
    next();
  } catch (error) { next(error); }
}
function requireUser(req, res, next) {
  if (!req.user) return res.status(401).json({ error: "Entre na sua conta para continuar." });
  next();
}
function sameOrigin(req, res, next) {
  if (req.get("sec-fetch-site") === "cross-site") return res.status(403).json({ error: "Origem não permitida." });
  const origin = req.get("origin");
  if (origin) {
    try { if (new URL(origin).host !== req.get("host")) return res.status(403).json({ error: "Origem não permitida." }); }
    catch { return res.status(403).json({ error: "Origem não permitida." }); }
  }
  next();
}
module.exports = { attachUser, createSession, hashPassword, readCookie, requireUser, sameOrigin, setCookie, sha256, verifyPassword };
