const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const file = path.resolve(process.env.DATABASE_PATH || path.join(__dirname, "..", "data", "scannatural.json"));
fs.mkdirSync(path.dirname(file), { recursive: true });
const blank = () => ({ users: [], pendingRegistrations: [], sessions: [], entries: [], goals: {}, webhookEvents: [] });
let state = blank();
if (fs.existsSync(file)) {
  try {
    const saved = JSON.parse(fs.readFileSync(file, "utf8"));
    state = Object.assign(blank(), saved);
  } catch {
    throw new Error("O arquivo de dados do ScanNatural não contém JSON válido.");
  }
}
function persist() {
  const temp = file + "." + process.pid + ".tmp";
  fs.writeFileSync(temp, JSON.stringify(state, null, 2), "utf8");
  fs.renameSync(temp, file);
}
function findUserByEmail(email) {
  return state.users.find((user) => user.email.toLowerCase() === email.toLowerCase()) || null;
}
function findPendingRegistration(email) {
  return state.pendingRegistrations.find((item) => item.email.toLowerCase() === email.toLowerCase()) || null;
}
function createPendingRegistration(registration) {
  if (findUserByEmail(registration.email) || findPendingRegistration(registration.email)) return false;
  state.pendingRegistrations.push(registration);
  persist();
  return true;
}
function updatePendingRegistration(email, values) {
  const registration = findPendingRegistration(email);
  if (!registration) return false;
  Object.assign(registration, values);
  persist();
  return true;
}
function removePendingRegistration(email) {
  const previous = state.pendingRegistrations.length;
  state.pendingRegistrations = state.pendingRegistrations.filter((item) => item.email.toLowerCase() !== email.toLowerCase());
  if (state.pendingRegistrations.length !== previous) persist();
}
function activatePendingRegistration(email) {
  const index = state.pendingRegistrations.findIndex((item) => item.email.toLowerCase() === email.toLowerCase());
  if (index < 0 || findUserByEmail(email)) return null;
  const registration = state.pendingRegistrations.splice(index, 1)[0];
  const user = { id: crypto.randomUUID(), name: registration.name, email: registration.email, password_hash: registration.password_hash, email_verified: true, billing_status: "free", created_at: new Date().toISOString() };
  state.users.push(user);
  state.goals[user.id] = { kcal: 2000, protein: 100, carbs: 250, fat: 70 };
  applyLatestBilling(user.email);
  persist();
  return user;
}
function applyLatestBilling(email) {
  const matches = state.webhookEvents.filter((event) => event.email === email).sort((a, b) => b.occurredAt.localeCompare(a.occurredAt) || b.id.localeCompare(a.id));
  const user = findUserByEmail(email);
  if (user && matches.length) user.billing_status = matches[0].event === "SALE_APPROVED" ? "premium" : "free";
}
function createUser(name, email, passwordHash) {
  if (findUserByEmail(email)) return null;
  const user = { id: crypto.randomUUID(), name, email, password_hash: passwordHash, billing_status: "free", created_at: new Date().toISOString() };
  state.users.push(user);
  state.goals[user.id] = { kcal: 2000, protein: 100, carbs: 250, fat: 70 };
  applyLatestBilling(email);
  persist();
  return user;
}
function findUserByGoogleId(googleSub) {
  return state.users.find((user) => user.google_sub === googleSub) || null;
}
function attachGoogleIdentity(userId, googleSub) {
  const user = findUserById(userId);
  if (!user || state.users.some((item) => item.google_sub === googleSub && item.id !== userId)) return false;
  user.google_sub = googleSub;
  persist();
  return true;
}
function createGoogleUser(name, email, googleSub) {
  if (findUserByEmail(email) || findUserByGoogleId(googleSub)) return null;
  const user = {
    id: crypto.randomUUID(),
    name: name || email.split("@")[0],
    email,
    password_hash: null,
    email_verified: true,
    google_sub: googleSub,
    billing_status: "free",
    created_at: new Date().toISOString()
  };
  state.users.push(user);
  state.goals[user.id] = { kcal: 2000, protein: 100, carbs: 250, fat: 70 };
  applyLatestBilling(email);
  persist();
  return user;
}
function findUserById(id) { return state.users.find((user) => user.id === id) || null; }
function createSession(tokenHash, userId, expiresAt) {
  state.sessions = state.sessions.filter((session) => session.user_id !== userId || session.expires_at > new Date().toISOString());
  state.sessions.push({ token_hash: tokenHash, user_id: userId, expires_at: expiresAt, created_at: new Date().toISOString() });
  persist();
}
function findSession(tokenHash) {
  return state.sessions.find((session) => session.token_hash === tokenHash && session.expires_at > new Date().toISOString()) || null;
}
function deleteSession(tokenHash) {
  state.sessions = state.sessions.filter((session) => session.token_hash !== tokenHash);
  persist();
}
function removeExpiredSessions() {
  const now = new Date().toISOString();
  const previous = state.sessions.length;
  state.sessions = state.sessions.filter((session) => session.expires_at > now);
  if (state.sessions.length !== previous) persist();
}
function getEntries(userId, day) {
  return state.entries.filter((entry) => entry.userId === userId && entry.day === day).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}
function createEntry(entry) {
  state.entries.push(entry);
  persist();
}
function deleteEntry(id, userId) {
  const index = state.entries.findIndex((entry) => entry.id === id && entry.userId === userId);
  if (index < 0) return false;
  state.entries.splice(index, 1);
  persist();
  return true;
}
function getGoals(userId) {
  return Object.assign({ kcal: 2000, protein: 100, carbs: 250, fat: 70 }, state.goals[userId] || {});
}
function setGoals(userId, goals) {
  state.goals[userId] = goals;
  persist();
}
function getHistory(userId, days, endDay) {
  const end = new Date(endDay + "T12:00:00Z");
  const rows = [];
  for (let i = days - 1; i >= 0; i -= 1) {
    const day = new Date(end.getTime() - i * 86400000).toISOString().slice(0, 10);
    const totals = { kcal: 0, protein: 0, carbs: 0, fat: 0 };
    for (const entry of state.entries) {
      if (entry.userId !== userId || entry.day !== day) continue;
      for (const key of Object.keys(totals)) totals[key] += entry.totals[key] || 0;
    }
    rows.push({ day, kcal: Math.round(totals.kcal), protein: Math.round(totals.protein), carbs: Math.round(totals.carbs), fat: Math.round(totals.fat) });
  }
  return rows;
}
function recordWebhook(saleId, event, email, occurredAt) {
  const duplicate = state.webhookEvents.some((row) => row.saleId === saleId && row.event === event);
  if (!duplicate) {
    state.webhookEvents.push({ id: crypto.randomUUID(), saleId, event, email, occurredAt, receivedAt: new Date().toISOString() });
    applyLatestBilling(email);
    persist();
  }
  return Boolean(findUserByEmail(email));
}
module.exports = { health: async () => ({ storage: "json-file" }), activatePendingRegistration, attachGoogleIdentity, createEntry, createGoogleUser, createPendingRegistration, createSession, createUser, deleteEntry, deleteSession, findPendingRegistration, findSession, findUserByEmail, findUserByGoogleId, findUserById, getEntries, getGoals, getHistory, recordWebhook, removeExpiredSessions, removePendingRegistration, setGoals, updatePendingRegistration };
