const tls = require("node:tls");

function smtpConfig() {
  const user = process.env.SMTP_USER || "";
  const pass = (process.env.SMTP_PASS || "").replace(/\s/g, "");
  const from = process.env.SMTP_FROM || user;
  if (!user || !pass || !from) return null;
  if (/[\r\n]/.test(user + from)) throw new Error("Configuracao SMTP invalida.");
  const fromAddress = from.match(/<([^<>]+)>/)?.[1] || from;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fromAddress)) throw new Error("SMTP_FROM deve conter um endereco de e-mail valido.");
  return { user, pass, from, fromAddress, host: process.env.SMTP_HOST || "smtp.gmail.com", port: Number(process.env.SMTP_PORT) || 465 };
}

function readReply(socket, state) {
  if (state.replies.length) return Promise.resolve(state.replies.shift());
  return new Promise((resolve, reject) => {
    state.waiters.push({ resolve, reject });
  });
}

function queueReply(state, lines) {
  const waiter = state.waiters.shift();
  if (waiter) waiter.resolve(lines);
  else state.replies.push(lines);
}

function expectCode(lines, allowed) {
  const last = lines[lines.length - 1] || "";
  const code = Number(last.slice(0, 3));
  if (!allowed.includes(code)) throw new Error("Servidor SMTP recusou a mensagem (" + code + ").");
}

async function sendVerificationCode(to, code, name) {
  const config = smtpConfig();
  if (!config) throw new Error("EMAIL_NOT_CONFIGURED");
  const socket = tls.connect({ host: config.host, port: config.port, servername: config.host });
  socket.setTimeout(15000, () => socket.destroy(new Error("Tempo limite de conexao SMTP.")));
  const state = { buffer: "", lines: [], replies: [], waiters: [] };
  socket.on("data", (chunk) => {
    state.buffer += chunk.toString("utf8");
    let end;
    while ((end = state.buffer.indexOf("\r\n")) >= 0) {
      const line = state.buffer.slice(0, end);
      state.buffer = state.buffer.slice(end + 2);
      state.lines.push(line);
      if (/^\d{3} /.test(line)) queueReply(state, state.lines.splice(0));
    }
  });
  socket.on("error", (error) => {
    while (state.waiters.length) state.waiters.shift().reject(error);
  });

  const command = async (value, allowed) => {
    socket.write(value + "\r\n");
    expectCode(await readReply(socket, state), allowed);
  };

  try {
    await new Promise((resolve, reject) => {
      socket.once("secureConnect", resolve);
      socket.once("error", reject);
    });
    expectCode(await readReply(socket, state), [220]);
    await command("EHLO scannatural.local", [250]);
    await command("AUTH LOGIN", [334]);
    await command(Buffer.from(config.user).toString("base64"), [334]);
    await command(Buffer.from(config.pass).toString("base64"), [235]);
    await command("MAIL FROM:<" + config.fromAddress + ">", [250]);
    await command("RCPT TO:<" + to + ">", [250, 251]);
    await command("DATA", [354]);

    const recipientName = String(name || "").replace(/[\r\n]/g, " ").slice(0, 80);
    const body = [
      "Ola" + (recipientName ? ", " + recipientName : "") + "!",
      "",
      "Seu codigo de verificacao do ScanNatural e: " + code,
      "",
      "O codigo expira em 10 minutos e pode ser usado uma unica vez.",
      "Se voce nao solicitou este cadastro, ignore esta mensagem."
    ].join("\r\n");
    const encodedBody = Buffer.from(body, "utf8").toString("base64").match(/.{1,76}/g).join("\r\n");
    const fromHeader = config.from.includes("<") ? config.from : "ScanNatural <" + config.fromAddress + ">";
    const message = [
      "From: " + fromHeader,
      "To: <" + to + ">",
      "Subject: Seu codigo de verificacao ScanNatural",
      "MIME-Version: 1.0",
      "Content-Type: text/plain; charset=UTF-8",
      "Content-Transfer-Encoding: base64",
      "",
      encodedBody
    ].join("\r\n").replace(/(^|\r\n)\./g, "$1..");
    socket.write(message + "\r\n.\r\n");
    expectCode(await readReply(socket, state), [250]);
    await command("QUIT", [221]);
  } finally {
    socket.end();
  }
}

module.exports = { sendVerificationCode };
