const useNetlifyDatabase = process.env.NETLIFY === "true" || process.env.DATABASE_DRIVER === "netlify";
module.exports = useNetlifyDatabase ? require("./database-netlify") : require("./database-json");
