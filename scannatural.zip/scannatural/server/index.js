require("dotenv").config();
const crypto = require("node:crypto");
const path = require("node:path");
const express = require("express");
const { OAuth2Client } = require("google-auth-library");
const store = require("./database");
const auth = require("./security");
const mailer = require("./mailer");
const app = express();
const googleAuthClient = new OAuth2Client();
const root = path.resolve(__dirname, "..");
const mealNames = new Set(["Café da manhã", "Almoço", "Lanche", "Jantar", "Outro"]);
const nutrientKeys = ["kcal", "protein", "carbs", "fat", "fiber", "sugar", "sodium"];
const attempts = new Map();
const assistantAttempts = new Map();
const emailCodeSecret = process.env.EMAIL_CODE_SECRET || crypto.randomBytes(32).toString("hex");

app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  next();
});
app.use(express.json({ limit: "5mb" }));
app.get("/api/health", async (req, res) => {
  try { res.json({ ok: true, app: "ScanNatural", ...(await store.health()) }); }
  catch (error) {
    console.error("ScanNatural health check failed:", error.message);
    const errorMessage = process.env.DATABASE_URL
      ? "Nao foi possivel conectar ao PostgreSQL. Confira a variavel DATABASE_URL."
      : "Banco do Netlify nao conectado. Crie o banco em Data & Storage > Database e publique novamente.";
    res.status(503).json({ ok: false, app: "ScanNatural", error: errorMessage });
  }
});
app.use(auth.attachUser);

const text = (value, max) => typeof value === "string" ? value.trim().slice(0, max) : "";
function limitAuth(req, res, next) {
  const key = req.ip || "unknown";
  let item = attempts.get(key);
  if (!item || item.until < Date.now()) { item = { count: 0, until: Date.now() + 900000 }; attempts.set(key, item); }
  item.count += 1;
  if (item.count > 20) return res.status(429).json({ error: "Muitas tentativas. Aguarde alguns minutos." });
  next();
}
function limitAssistant(req, res, next) {
  const key = req.user.id;
  let item = assistantAttempts.get(key);
  if (!item || item.until < Date.now()) { item = { count: 0, until: Date.now() + 300000 }; assistantAttempts.set(key, item); }
  item.count += 1;
  if (item.count > 15) return res.status(429).json({ error: "Voce atingiu o limite de mensagens por enquanto. Tente novamente em alguns minutos." });
  next();
}
function emailCodeHash(email, code) {
  return crypto.createHmac("sha256", emailCodeSecret).update(email + ":" + code).digest();
}
function matchesEmailCode(email, code, savedHash) {
  const expected = Buffer.from(savedHash || "", "hex");
  const actual = emailCodeHash(email, code);
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}
function validDay(day) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day || "")) return false;
  const date = new Date(day + "T12:00:00Z");
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === day;
}
function userView(user) {
  return { id: user.id, name: user.name, email: user.email, emailVerified: user.email_verified !== false, billingStatus: user.billing_status };
}
function cleanItems(list) {
  if (!Array.isArray(list) || list.length < 1 || list.length > 30) return null;
  const result = [];
  for (const item of list) {
    const name = text(item && item.name, 80);
    const grams = Number(item && item.grams);
    if (!name || !Number.isFinite(grams) || grams <= 0 || grams > 10000) return null;
    const values = {};
    for (const key of nutrientKeys) {
      const n = Number(item.nutrients && item.nutrients[key]);
      if (!Number.isFinite(n) || n < 0 || n > 100000) return null;
      values[key] = Math.round(n * 10) / 10;
    }
    result.push({ id: text(item.id, 80) || crypto.randomUUID(), name, grams: Math.round(grams), nutrients: values });
  }
  return result;
}
function sumItems(items) {
  const total = Object.fromEntries(nutrientKeys.map((key) => [key, 0]));
  for (const item of items) for (const key of nutrientKeys) total[key] += item.nutrients[key];
  for (const key of nutrientKeys) total[key] = Math.round(total[key] * 10) / 10;
  return total;
}

app.get("/api/public-config", (req, res) => res.json({ googleClientId: process.env.GOOGLE_CLIENT_ID || "" }));
app.post("/api/auth/register", auth.sameOrigin, limitAuth, async (req, res, next) => {
  try {
    const name = text(req.body && req.body.name, 80);
    const email = text(req.body && req.body.email, 254).toLowerCase();
    const password = req.body && req.body.password;
    if (name.length < 2) return res.status(400).json({ error: "Informe seu nome." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Informe um e-mail válido." });
    if (typeof password !== "string" || password.length < 8 || password.length > 128) return res.status(400).json({ error: "A senha precisa ter entre 8 e 128 caracteres." });
    if (!process.env.SMTP_USER || !process.env.SMTP_PASS) return res.status(503).json({ error: "O envio de e-mail ainda não está configurado. Defina SMTP_USER e SMTP_PASS no servidor." });
    if (process.env.NETLIFY === "true" && !process.env.EMAIL_CODE_SECRET) return res.status(503).json({ error: "Defina EMAIL_CODE_SECRET nas variaveis do Netlify para ativar a confirmacao por e-mail." });
    if (await store.findUserByEmail(email)) return res.status(409).json({ error: "Já existe uma conta com esse e-mail. Entre na sua conta." });
    const now = Date.now();
    let pending = await store.findPendingRegistration(email);
    if (pending && now - Date.parse(pending.last_sent_at) < 60000) {
      await store.updatePendingRegistration(email, { name, password_hash: await auth.hashPassword(password) });
      return res.status(202).json({ verificationRequired: true, email });
    }
    const code = String(crypto.randomInt(100000, 1000000));
    const passwordHash = await auth.hashPassword(password);
    try {
      await mailer.sendVerificationCode(email, code, name);
    } catch (error) {
      console.error("Falha ao enviar codigo de verificacao:", error.message);
      return res.status(502).json({ error: "Não foi possível enviar o código. Confira as credenciais SMTP e tente novamente." });
    }
    const registration = {
      email,
      name,
      password_hash: passwordHash,
      code_hash: emailCodeHash(email, code).toString("hex"),
      attempts: 0,
      created_at: new Date(now).toISOString(),
      expires_at: new Date(now + 10 * 60000).toISOString(),
      last_sent_at: new Date(now).toISOString()
    };
    if (pending) await store.updatePendingRegistration(email, registration);
    else if (!(await store.createPendingRegistration(registration))) return res.status(409).json({ error: "Já existe um cadastro em andamento para esse e-mail. Tente novamente." });
    res.status(202).json({ verificationRequired: true, email });
  } catch (error) { next(error); }
});
app.post("/api/auth/verify-email", auth.sameOrigin, limitAuth, async (req, res) => {
  const email = text(req.body && req.body.email, 254).toLowerCase();
  const code = text(req.body && req.body.code, 6);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !/^\d{6}$/.test(code)) return res.status(400).json({ error: "Informe o e-mail e o código de seis dígitos." });
  const pending = await store.findPendingRegistration(email);
  if (!pending) return res.status(404).json({ error: "Cadastro pendente não encontrado. Comece novamente." });
  if (Date.parse(pending.expires_at) <= Date.now()) {
    await store.removePendingRegistration(email);
    return res.status(410).json({ error: "O código expirou. Crie sua conta novamente para receber outro." });
  }
  if (pending.attempts >= 5) return res.status(429).json({ error: "Limite de tentativas atingido. Crie sua conta novamente para receber outro código." });
  if (!matchesEmailCode(email, code, pending.code_hash)) {
    await store.updatePendingRegistration(email, { attempts: pending.attempts + 1 });
    return res.status(400).json({ error: "Código incorreto. Confira o e-mail e tente novamente." });
  }
  const user = await store.activatePendingRegistration(email);
  if (!user) return res.status(409).json({ error: "Não foi possível concluir o cadastro. Tente novamente." });
  await auth.createSession(user.id, res);
  res.status(201).json({ user: userView(user) });
});
app.post("/api/auth/resend-code", auth.sameOrigin, limitAuth, async (req, res) => {
  const email = text(req.body && req.body.email, 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Informe um e-mail válido." });
  const pending = await store.findPendingRegistration(email);
  if (!pending) return res.status(404).json({ error: "Cadastro pendente não encontrado. Comece novamente." });
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) return res.status(503).json({ error: "O envio de e-mail ainda não está configurado no servidor." });
  if (process.env.NETLIFY === "true" && !process.env.EMAIL_CODE_SECRET) return res.status(503).json({ error: "Defina EMAIL_CODE_SECRET nas variaveis do Netlify para ativar a confirmacao por e-mail." });
  if (Date.now() - Date.parse(pending.last_sent_at) < 60000) return res.status(429).json({ error: "Aguarde um minuto antes de solicitar outro código." });
  const code = String(crypto.randomInt(100000, 1000000));
  try {
    await mailer.sendVerificationCode(email, code, pending.name);
    const now = Date.now();
    await store.updatePendingRegistration(email, {
      code_hash: emailCodeHash(email, code).toString("hex"),
      attempts: 0,
      expires_at: new Date(now + 10 * 60000).toISOString(),
      last_sent_at: new Date(now).toISOString()
    });
    res.json({ sent: true });
  } catch (error) {
    console.error("Falha ao reenviar codigo de verificacao:", error.message);
    res.status(502).json({ error: "Não foi possível enviar o código. Confira as credenciais SMTP e tente novamente." });
  }
});
app.post("/api/auth/login", auth.sameOrigin, limitAuth, async (req, res, next) => {
  try {
    const email = text(req.body && req.body.email, 254).toLowerCase();
    const password = req.body && req.body.password;
    const user = await store.findUserByEmail(email);
    if (!user || typeof password !== "string" || !await auth.verifyPassword(password, user.password_hash)) return res.status(401).json({ error: "E-mail ou senha incorretos." });
    await auth.createSession(user.id, res);
    res.json({ user: userView(user) });
  } catch (error) { next(error); }
});
app.post("/api/auth/google", auth.sameOrigin, limitAuth, async (req, res) => {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  if (!clientId) return res.status(503).json({ error: "O login com Google ainda não foi configurado no servidor." });
  const credential = text(req.body && req.body.credential, 20000);
  if (!credential) return res.status(400).json({ error: "O Google não retornou uma credencial válida." });

  let payload;
  try {
    const ticket = await googleAuthClient.verifyIdToken({ idToken: credential, audience: clientId });
    payload = ticket.getPayload();
  } catch {
    return res.status(401).json({ error: "Não foi possível validar sua conta Google. Tente novamente." });
  }
  const googleSub = text(payload && payload.sub, 255);
  const email = text(payload && payload.email, 254).toLowerCase();
  if (!googleSub || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || payload.email_verified !== true) {
    return res.status(401).json({ error: "A conta Google não forneceu um e-mail verificado." });
  }

  let user = await store.findUserByGoogleId(googleSub);
  if (!user) {
    const existing = await store.findUserByEmail(email);
    if (existing) {
      const googleControlsEmail = email.endsWith("@gmail.com") || Boolean(payload.hd);
      if (existing.email_verified !== true || !googleControlsEmail) {
        return res.status(409).json({ error: "Já existe uma conta com esse e-mail. Entre com e-mail e senha para acessar." });
      }
      if (!(await store.attachGoogleIdentity(existing.id, googleSub))) {
        return res.status(409).json({ error: "Não foi possível vincular esta conta Google. Entre com e-mail e senha." });
      }
      user = await store.findUserById(existing.id);
    } else {
      user = await store.createGoogleUser(text(payload.name, 80), email, googleSub);
    }
  }
  if (!user) return res.status(409).json({ error: "Já existe uma conta associada a este e-mail. Entre na sua conta." });
  await auth.createSession(user.id, res);
  res.json({ user: userView(user) });
});
app.get("/api/auth/me", (req, res) => res.json({ user: req.user ? userView(req.user) : null }));
app.post("/api/auth/logout", auth.sameOrigin, async (req, res) => {
  const token = auth.readCookie(req);
  if (token) await store.deleteSession(auth.sha256(token));
  auth.setCookie(res, "", true);
  res.json({ ok: true });
});

app.get("/api/entries", auth.requireUser, async (req, res) => {
  const day = text(req.query.day, 10);
  if (!validDay(day)) return res.status(400).json({ error: "Data inválida." });
  res.json({ entries: await store.getEntries(req.user.id, day) });
});
app.post("/api/entries", auth.sameOrigin, auth.requireUser, async (req, res) => {
  const day = text(req.body && req.body.day, 10);
  const meal = text(req.body && req.body.meal, 40);
  if (!validDay(day)) return res.status(400).json({ error: "Data inválida." });
  if (!mealNames.has(meal)) return res.status(400).json({ error: "Escolha uma refeição válida." });
  const items = cleanItems(req.body && req.body.items);
  if (!items) return res.status(400).json({ error: "Confira os alimentos e tente novamente." });
  const entry = { id: crypto.randomUUID(), userId: req.user.id, day, meal, items, totals: sumItems(items), createdAt: new Date().toISOString() };
  await store.createEntry(entry);
  res.status(201).json({ entry });
});
app.delete("/api/entries/:id", auth.sameOrigin, auth.requireUser, async (req, res) => {
  if (!(await store.deleteEntry(req.params.id, req.user.id))) return res.status(404).json({ error: "Registro não encontrado." });
  res.json({ ok: true });
});
app.get("/api/goals", auth.requireUser, async (req, res) => res.json({ goals: await store.getGoals(req.user.id) }));
app.put("/api/goals", auth.sameOrigin, auth.requireUser, async (req, res) => {
  const limits = { kcal: [500, 10000], protein: [0, 500], carbs: [0, 1000], fat: [0, 500] };
  const values = {};
  for (const [key, range] of Object.entries(limits)) {
    const value = Number(req.body && req.body[key]);
    if (!Number.isFinite(value) || value < range[0] || value > range[1]) return res.status(400).json({ error: "Confira os valores das metas." });
    values[key] = Math.round(value);
  }
  await store.setGoals(req.user.id, values);
  res.json({ goals: values });
});
app.get("/api/history", auth.requireUser, async (req, res) => {
  const days = [7, 14, 30].includes(Number(req.query.days)) ? Number(req.query.days) : 7;
  const requestedEnd = text(req.query.end, 10);
  const end = validDay(requestedEnd) ? requestedEnd : new Date().toISOString().slice(0, 10);
  res.json({ history: await store.getHistory(req.user.id, days, end) });
});

app.post("/api/assistant/chat", auth.sameOrigin, auth.requireUser, limitAssistant, async (req, res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "O assistente de IA ainda não está configurado. Defina OPENAI_API_KEY no servidor." });
  const messages = req.body && req.body.messages;
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 10) return res.status(400).json({ error: "Envie até dez mensagens para manter a conversa." });
  const history = [];
  for (const message of messages) {
    const role = message && message.role;
    const content = text(message && message.content, 600);
    if (!["user", "assistant"].includes(role) || !content) return res.status(400).json({ error: "Confira o conteúdo da conversa." });
    history.push((role === "assistant" ? "Assistente" : "Pessoa") + ": " + content);
  }
  if (messages[messages.length - 1].role !== "user") return res.status(400).json({ error: "A última mensagem precisa ser uma pergunta." });
  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": "Bearer " + process.env.OPENAI_API_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-6-luna",
        instructions: "Voce e o assistente de nutricao geral do ScanNatural. Responda em portugues brasileiro, de forma cordial, simples e objetiva, sobre alimentacao e nutricao geral. Trate qualquer numero nutricional como estimativa. Nao diagnostique, nao prescreva tratamento, suplementos ou dietas restritivas e nao substitua nutricionista ou medico. Para condicoes de saude, sintomas, gravidez, transtornos alimentares, alergias ou medicacao, recomende acompanhamento profissional. Se perguntarem algo fora de alimentacao, explique brevemente que seu foco e nutricao.",
        input: history.join("\n"),
        max_output_tokens: 450,
        store: false
      })
    });
    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("OpenAI API returned status", upstream.status);
      return res.status(upstream.status === 429 ? 503 : 502).json({ error: upstream.status === 429 ? "O assistente está ocupado. Tente novamente em instantes." : "Não foi possível obter uma resposta agora. Tente novamente." });
    }
    const reply = (result.output || []).flatMap((item) => item.type === "message" ? (item.content || []).filter((part) => part.type === "output_text").map((part) => part.text) : []).join("\n").trim();
    if (!reply) return res.status(502).json({ error: "O assistente não retornou uma resposta. Tente novamente." });
    res.json({ reply });
  } catch (error) {
    console.error("Falha ao consultar o assistente:", error.message);
    res.status(502).json({ error: "Não foi possível conectar ao assistente. Tente novamente." });
  }
});

app.post("/api/assistant/analyze-food-photo", auth.sameOrigin, auth.requireUser, limitAssistant, async (req, res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "A análise de fotos ainda não está configurada. Defina OPENAI_API_KEY no servidor." });
  const imageDataUrl = req.body && req.body.imageDataUrl;
  if (typeof imageDataUrl !== "string" || imageDataUrl.length > 4300000) return res.status(413).json({ error: "A foto é muito grande. Escolha uma imagem menor." });
  const match = imageDataUrl.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/);
  if (!match) return res.status(400).json({ error: "Envie uma foto JPEG, PNG ou WebP válida." });
  const imageBytes = Buffer.from(match[2], "base64");
  if (!imageBytes.length || imageBytes.length > 3 * 1024 * 1024) return res.status(413).json({ error: "A foto precisa ter menos de 3 MB depois da compressão." });
  const portion = text(req.body && req.body.portion, 120);
  const meal = text(req.body && req.body.meal, 40);
  if (meal && !mealNames.has(meal)) return res.status(400).json({ error: "Escolha uma refeição válida." });

  const schema = {
    type: "object",
    properties: {
      is_food: { type: "boolean" },
      food_name: { type: "string" },
      portion_estimate: { type: "string" },
      calories_min: { type: "integer", minimum: 0, maximum: 10000 },
      calories_max: { type: "integer", minimum: 0, maximum: 10000 },
      confidence: { type: "string", enum: ["low", "medium", "high"] },
      note: { type: "string" }
    },
    required: ["is_food", "food_name", "portion_estimate", "calories_min", "calories_max", "confidence", "note"],
    additionalProperties: false
  };
  const prompt = [
    "Identifique o alimento ou prato visível e estime o intervalo de calorias para a porção que aparece na foto, não por 100 g.",
    "Considere a descrição de porção informada pela pessoa quando existir. Se não houver escala, deixe claro que o peso é apenas visual e use uma faixa mais ampla.",
    "Não invente ingredientes escondidos. Em prato misto, estime o prato como um todo e explique as maiores incertezas na nota.",
    "Se a imagem não mostrar alimento ou não permitir identificação minimamente útil, retorne is_food=false, valores de calorias 0, confiança low e explique o motivo na nota.",
    "Refeição: " + (meal || "não informada"),
    "Descrição da porção: " + (portion || "não informada")
  ].join("\n");

  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": "Bearer " + process.env.OPENAI_API_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_VISION_MODEL || "gpt-6-astra",
        instructions: "Você analisa fotos de alimentos para oferecer estimativas gerais. Seja conservador e transparente: a imagem não informa com precisão peso, óleo, molhos, receita ou ingredientes ocultos. Não apresente a faixa como medição exata nem como recomendação médica. Responda em português brasileiro dentro do formato estruturado solicitado.",
        input: [{ role: "user", content: [
          { type: "input_text", text: prompt },
          { type: "input_image", image_url: imageDataUrl, detail: "auto" }
        ] }],
        text: { format: { type: "json_schema", name: "food_photo_estimate", strict: true, schema } },
        max_output_tokens: 350,
        store: false
      })
    });
    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("OpenAI image analysis returned status", upstream.status);
      return res.status(upstream.status === 429 ? 503 : 502).json({ error: upstream.status === 429 ? "O analisador está ocupado. Tente novamente em instantes." : "Não foi possível analisar essa foto. Tente novamente." });
    }
    const raw = (result.output || []).flatMap((item) => item.type === "message" ? (item.content || []).filter((part) => part.type === "output_text").map((part) => part.text) : []).join("");
    const estimate = JSON.parse(raw);
    if (typeof estimate.is_food !== "boolean" || !["low", "medium", "high"].includes(estimate.confidence) || !Number.isInteger(estimate.calories_min) || !Number.isInteger(estimate.calories_max) || estimate.calories_min < 0 || estimate.calories_max < estimate.calories_min || estimate.calories_max > 10000) throw new Error("Resposta nutricional fora do formato esperado.");
    estimate.food_name = text(estimate.food_name, 100);
    estimate.portion_estimate = text(estimate.portion_estimate, 120);
    estimate.note = text(estimate.note, 240);
    res.json({ estimate });
  } catch (error) {
    console.error("Falha ao analisar foto de alimento:", error.message);
    res.status(502).json({ error: "Não foi possível interpretar a foto. Tente uma imagem mais clara e aproximada." });
  }
});

app.post("/api/webhooks/kirvano", async (req, res) => {
  const secret = process.env.KIRVANO_WEBHOOK_TOKEN;
  if (!secret) return res.status(503).json({ error: "Webhook ainda não configurado." });
  const supplied = req.get("x-kirvano-token") || (req.get("authorization") || "").replace(/^Bearer\s+/i, "") || text(req.body && req.body.token, 500);
  const expected = Buffer.from(secret), actual = Buffer.from(supplied);
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) return res.status(401).json({ error: "Token do webhook inválido." });
  const event = text(req.body && req.body.event, 80).toUpperCase();
  const accepted = new Set(["SALE_APPROVED", "SALE_REFUNDED", "SALE_CHARGEBACK", "SUBSCRIPTION_CANCELED"]);
  if (!accepted.has(event)) return res.json({ received: true, ignored: true });
  const saleId = text(req.body && req.body.sale_id, 120);
  const email = text(req.body && req.body.customer && req.body.customer.email, 254).toLowerCase();
  if (!saleId || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Evento sem sale_id ou e-mail válido." });
  const products = Array.isArray(req.body.products) ? req.body.products : [];
  if (process.env.KIRVANO_PRODUCT_ID && !products.some((product) => String(product.id) === process.env.KIRVANO_PRODUCT_ID)) return res.json({ received: true, ignored: true });
  const parsed = new Date(text(req.body && req.body.created_at, 40).replace(" ", "T"));
  const occurredAt = Number.isNaN(parsed.getTime()) ? new Date().toISOString() : parsed.toISOString();
  const matchedAccount = await store.recordWebhook(saleId, event, email, occurredAt);
  res.json({ received: true, matchedAccount });
});

app.use("/css", express.static(path.join(root, "css"), { fallthrough: false, maxAge: "1h" }));
app.use("/js", express.static(path.join(root, "js"), { fallthrough: false, maxAge: "1h" }));
app.get("/", (req, res) => res.sendFile(path.join(root, "index.html")));
app.use("/api", (req, res) => res.status(404).json({ error: "Rota não encontrada." }));
app.use((error, req, res, next) => {
  console.error("Request failed:", error.message);
  if (res.headersSent) return next(error);
  res.status(500).json({ error: "Ocorreu um erro no servidor. Tente novamente." });
});
if (require.main === module) {
  const cleanup = setInterval(() => {
    for (const [key, item] of attempts) if (item.until < Date.now()) attempts.delete(key);
    for (const [key, item] of assistantAttempts) if (item.until < Date.now()) assistantAttempts.delete(key);
    Promise.resolve(store.removeExpiredSessions()).catch((error) => console.error("Falha ao limpar sessoes:", error.message));
  }, 6 * 60 * 60 * 1000);
  cleanup.unref();
  const port = Number(process.env.PORT) || 3000;
  app.listen(port, () => console.log("ScanNatural disponivel em http://localhost:" + port));
}
module.exports = app;
