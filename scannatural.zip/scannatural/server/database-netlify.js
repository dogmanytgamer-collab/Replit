const crypto = require("node:crypto");

let databasePromise;
async function getDatabase() {
  if (!databasePromise) {
    databasePromise = import("@netlify/database").then((module) => process.env.DATABASE_URL ? module.getDatabase({ connectionString: process.env.DATABASE_URL }) : module.getDatabase());
  }
  return databasePromise;
}
async function query(statement, values) {
  const database = await getDatabase();
  return database.sql.unsafe(statement, values || []);
}
function dayText(value) {
  return value instanceof Date ? value.toISOString().slice(0, 10) : String(value).slice(0, 10);
}
async function findUserByEmail(email) {
  const rows = await query("SELECT * FROM users WHERE lower(email) = lower($1) LIMIT 1", [email]);
  return rows[0] || null;
}
async function findPendingRegistration(email) {
  const rows = await query("SELECT * FROM pending_registrations WHERE lower(email) = lower($1) LIMIT 1", [email]);
  return rows[0] || null;
}
async function createPendingRegistration(registration) {
  const rows = await query(
    "INSERT INTO pending_registrations (email, name, password_hash, code_hash, attempts, created_at, expires_at, last_sent_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT (email) DO NOTHING RETURNING email",
    [registration.email.toLowerCase(), registration.name, registration.password_hash, registration.code_hash, registration.attempts || 0, registration.created_at, registration.expires_at, registration.last_sent_at]
  );
  return rows.length > 0;
}
const pendingColumns = new Set(["name", "password_hash", "code_hash", "attempts", "created_at", "expires_at", "last_sent_at"]);
async function updatePendingRegistration(email, values) {
  const entries = Object.entries(values || {}).filter(([key]) => pendingColumns.has(key));
  if (!entries.length) return false;
  const assignments = entries.map(([key], index) => key + " = $" + (index + 2)).join(", ");
  const params = [email.toLowerCase(), ...entries.map(([, value]) => value)];
  const rows = await query("UPDATE pending_registrations SET " + assignments + " WHERE lower(email) = lower($1) RETURNING email", params);
  return rows.length > 0;
}
async function removePendingRegistration(email) {
  await query("DELETE FROM pending_registrations WHERE lower(email) = lower($1)", [email.toLowerCase()]);
}
async function applyLatestBilling(email, client) {
  const rows = client
    ? (await client.query("SELECT event FROM webhook_events WHERE lower(email)=lower($1) ORDER BY occurred_at DESC, id DESC LIMIT 1", [email])).rows
    : await query("SELECT event FROM webhook_events WHERE lower(email)=lower($1) ORDER BY occurred_at DESC, id DESC LIMIT 1", [email]);
  const status = rows.length ? (rows[0].event === "SALE_APPROVED" ? "premium" : "free") : null;
  if (status) {
    if (client) await client.query("UPDATE users SET billing_status=$1 WHERE lower(email)=lower($2)", [status, email]);
    else await query("UPDATE users SET billing_status=$1 WHERE lower(email)=lower($2)", [status, email]);
  }
  return status;
}
async function activatePendingRegistration(email) {
  const database = await getDatabase();
  const client = await database.pool.connect();
  try {
    await client.query("BEGIN");
    const pendingResult = await client.query("SELECT * FROM pending_registrations WHERE lower(email)=lower($1) FOR UPDATE", [email.toLowerCase()]);
    const registration = pendingResult.rows[0];
    if (!registration) {
      await client.query("ROLLBACK");
      return null;
    }
    const existing = await client.query("SELECT id FROM users WHERE lower(email)=lower($1) LIMIT 1", [email.toLowerCase()]);
    if (existing.rows.length) {
      await client.query("DELETE FROM pending_registrations WHERE lower(email)=lower($1)", [email.toLowerCase()]);
      await client.query("COMMIT");
      return null;
    }
    const id = crypto.randomUUID();
    const inserted = await client.query(
      "INSERT INTO users (id,name,email,password_hash,email_verified,billing_status,created_at) VALUES ($1,$2,$3,$4,true,'free',NOW()) RETURNING *",
      [id, registration.name, registration.email.toLowerCase(), registration.password_hash]
    );
    await client.query("INSERT INTO goals (user_id,kcal,protein,carbs,fat) VALUES ($1,2000,100,250,70)", [id]);
    await applyLatestBilling(registration.email, client);
    await client.query("DELETE FROM pending_registrations WHERE lower(email)=lower($1)", [email.toLowerCase()]);
    const refreshed = await client.query("SELECT * FROM users WHERE id=$1", [id]);
    await client.query("COMMIT");
    return refreshed.rows[0] || inserted.rows[0] || null;
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}
async function createUser(name, email, passwordHash) {
  const database = await getDatabase();
  const client = await database.pool.connect();
  const id = crypto.randomUUID();
  try {
    await client.query("BEGIN");
    const inserted = await client.query(
      "INSERT INTO users (id,name,email,password_hash,billing_status,created_at) VALUES ($1,$2,$3,$4,'free',NOW()) ON CONFLICT DO NOTHING RETURNING *",
      [id, name, email.toLowerCase(), passwordHash]
    );
    if (!inserted.rows.length) {
      await client.query("ROLLBACK");
      return null;
    }
    await client.query("INSERT INTO goals (user_id,kcal,protein,carbs,fat) VALUES ($1,2000,100,250,70)", [id]);
    await applyLatestBilling(email, client);
    const refreshed = await client.query("SELECT * FROM users WHERE id=$1", [id]);
    await client.query("COMMIT");
    return refreshed.rows[0] || inserted.rows[0];
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}
async function findUserByGoogleId(googleSub) {
  const rows = await query("SELECT * FROM users WHERE google_sub=$1 LIMIT 1", [googleSub]);
  return rows[0] || null;
}
async function attachGoogleIdentity(userId, googleSub) {
  const rows = await query(
    "UPDATE users SET google_sub=$2 WHERE id=$1 AND NOT EXISTS (SELECT 1 FROM users WHERE google_sub=$2 AND id<>$1) RETURNING id",
    [userId, googleSub]
  );
  return rows.length > 0;
}
async function createGoogleUser(name, email, googleSub) {
  const database = await getDatabase();
  const client = await database.pool.connect();
  const id = crypto.randomUUID();
  try {
    await client.query("BEGIN");
    const inserted = await client.query(
      "INSERT INTO users (id,name,email,password_hash,email_verified,google_sub,billing_status,created_at) VALUES ($1,$2,$3,NULL,true,$4,'free',NOW()) ON CONFLICT DO NOTHING RETURNING *",
      [id, name || email.split("@")[0], email.toLowerCase(), googleSub]
    );
    if (!inserted.rows.length) {
      await client.query("ROLLBACK");
      return null;
    }
    await client.query("INSERT INTO goals (user_id,kcal,protein,carbs,fat) VALUES ($1,2000,100,250,70)", [id]);
    await applyLatestBilling(email, client);
    const refreshed = await client.query("SELECT * FROM users WHERE id=$1", [id]);
    await client.query("COMMIT");
    return refreshed.rows[0] || inserted.rows[0];
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}
async function findUserById(id) {
  const rows = await query("SELECT * FROM users WHERE id=$1 LIMIT 1", [id]);
  return rows[0] || null;
}
async function createSession(tokenHash, userId, expiresAt) {
  await query("DELETE FROM sessions WHERE user_id=$1 AND expires_at <= NOW()", [userId]);
  await query("INSERT INTO sessions (token_hash,user_id,expires_at,created_at) VALUES ($1,$2,$3,NOW())", [tokenHash, userId, expiresAt]);
}
async function findSession(tokenHash) {
  const rows = await query("SELECT * FROM sessions WHERE token_hash=$1 AND expires_at>NOW() LIMIT 1", [tokenHash]);
  return rows[0] || null;
}
async function deleteSession(tokenHash) {
  await query("DELETE FROM sessions WHERE token_hash=$1", [tokenHash]);
}
async function removeExpiredSessions() {
  await query("DELETE FROM sessions WHERE expires_at<=NOW()");
}
async function getEntries(userId, day) {
  return query(
    "SELECT id,user_id AS \"userId\",day::text AS day,meal,items,totals,created_at AS \"createdAt\" FROM entries WHERE user_id=$1 AND day=$2::date ORDER BY created_at ASC",
    [userId, day]
  );
}
async function createEntry(entry) {
  await query(
    "INSERT INTO entries (id,user_id,day,meal,items,totals,created_at) VALUES ($1,$2,$3::date,$4,$5::jsonb,$6::jsonb,$7)",
    [entry.id, entry.userId, entry.day, entry.meal, JSON.stringify(entry.items), JSON.stringify(entry.totals), entry.createdAt]
  );
}
async function deleteEntry(id, userId) {
  const rows = await query("DELETE FROM entries WHERE id=$1 AND user_id=$2 RETURNING id", [id, userId]);
  return rows.length > 0;
}
async function getGoals(userId) {
  const rows = await query("SELECT kcal,protein,carbs,fat FROM goals WHERE user_id=$1 LIMIT 1", [userId]);
  return Object.assign({ kcal: 2000, protein: 100, carbs: 250, fat: 70 }, rows[0] || {});
}
async function setGoals(userId, goals) {
  await query(
    "INSERT INTO goals (user_id,kcal,protein,carbs,fat) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (user_id) DO UPDATE SET kcal=EXCLUDED.kcal,protein=EXCLUDED.protein,carbs=EXCLUDED.carbs,fat=EXCLUDED.fat",
    [userId, goals.kcal, goals.protein, goals.carbs, goals.fat]
  );
}
async function getHistory(userId, days, endDay) {
  const end = new Date(endDay + "T00:00:00Z");
  const start = new Date(end.getTime() - (days - 1) * 86400000);
  const startDay = start.toISOString().slice(0, 10);
  const rows = await query(
    "SELECT day::text AS day, COALESCE(SUM((totals->>'kcal')::numeric),0) AS kcal, COALESCE(SUM((totals->>'protein')::numeric),0) AS protein, COALESCE(SUM((totals->>'carbs')::numeric),0) AS carbs, COALESCE(SUM((totals->>'fat')::numeric),0) AS fat FROM entries WHERE user_id=$1 AND day BETWEEN $2::date AND $3::date GROUP BY day ORDER BY day",
    [userId, startDay, endDay]
  );
  const byDay = new Map(rows.map((row) => [dayText(row.day), row]));
  const history = [];
  for (let offset = days - 1; offset >= 0; offset -= 1) {
    const day = new Date(end.getTime() - offset * 86400000).toISOString().slice(0, 10);
    const row = byDay.get(day) || {};
    history.push({
      day,
      kcal: Math.round(Number(row.kcal) || 0),
      protein: Math.round(Number(row.protein) || 0),
      carbs: Math.round(Number(row.carbs) || 0),
      fat: Math.round(Number(row.fat) || 0)
    });
  }
  return history;
}
async function recordWebhook(saleId, event, email, occurredAt) {
  const rows = await query(
    "INSERT INTO webhook_events (id,sale_id,event,email,occurred_at,received_at) VALUES ($1,$2,$3,$4,$5,NOW()) ON CONFLICT (sale_id,event) DO NOTHING RETURNING id",
    [crypto.randomUUID(), saleId, event, email.toLowerCase(), occurredAt]
  );
  if (rows.length) await applyLatestBilling(email);
  const users = await query("SELECT id FROM users WHERE lower(email)=lower($1) LIMIT 1", [email]);
  return users.length > 0;
}
async function health() {
  await query("SELECT 1 AS ok");
  return { storage: process.env.DATABASE_URL ? "external-postgres" : "netlify-postgres" };
}
module.exports = {
  health, activatePendingRegistration, attachGoogleIdentity, createEntry, createGoogleUser, createPendingRegistration,
  createSession, createUser, deleteEntry, deleteSession, findPendingRegistration, findSession,
  findUserByEmail, findUserByGoogleId, findUserById, getEntries, getGoals, getHistory, recordWebhook,
  removeExpiredSessions, removePendingRegistration, setGoals, updatePendingRegistration
};
