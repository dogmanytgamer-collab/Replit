process.env.DATABASE_DRIVER = "netlify";
process.env.NETLIFY = "true";
const serverless = require("serverless-http");
const app = require("../../server/index");
exports.handler = serverless(app);
