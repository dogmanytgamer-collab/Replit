# ScanNatural

Aplicativo de diário alimentar para registrar refeições, acompanhar estimativas nutricionais, conversar com um assistente e analisar fotos de alimentos.

As informações nutricionais são estimativas e não substituem a orientação de nutricionista.

## Publicar no Netlify

O projeto foi preparado para publicar o site estático e a API Express como Netlify Function. A API usa PostgreSQL do Netlify para contas, sessões, refeições, metas e eventos da Kirvano.

### 1. Envie o projeto por Git

Conecte ao Netlify o repositório GitHub que contém estes arquivos. A publicação manual somente dos arquivos estáticos não envia a Function nem aplica as migrações do banco.

### 2. Crie o banco

No painel do site Netlify, abra Data & Storage → Database e crie um banco. A migração em netlify/database/migrations cria as tabelas no deploy. A disponibilidade do banco depende do plano Netlify. Se essa opcao nao estiver disponivel, use um PostgreSQL gerenciado externo, execute o SQL da migracao no painel dele e cadastre a conexao em DATABASE_URL nas variaveis do Netlify.

### 3. Configure as variáveis no painel

Em Project configuration → Environment variables, adicione as variáveis que usa. Ative o escopo Functions para essas variaveis:

Obrigatórias para criar contas com confirmação por e-mail:
- DATABASE_URL (somente se usar PostgreSQL externo)
- SMTP_HOST (por exemplo, smtp.gmail.com)
- SMTP_PORT (465 para SSL)
- SMTP_USER
- SMTP_PASS (senha de app do Gmail)
- EMAIL_CODE_SECRET (segredo permanente, não compartilhe)

Para login Google:
- GOOGLE_CLIENT_ID

Para assistente e análise de fotos:
- OPENAI_API_KEY
- OPENAI_MODEL (opcional; padrão definido no código)
- OPENAI_VISION_MODEL (opcional; padrão definido no código)

Para webhook Kirvano:
- KIRVANO_WEBHOOK_TOKEN
- KIRVANO_PRODUCT_ID (opcional)

Gere EMAIL_CODE_SECRET no PowerShell com:

    node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

Copie o resultado diretamente para a variável no Netlify. Não coloque segredos no HTML, JavaScript do navegador ou repositório. No Google Cloud, adicione a origem publicada, por exemplo https://kaleidoscopic-frangipane-37fbd4.netlify.app, às origens JavaScript autorizadas do cliente OAuth.

### 4. Use estas configurações de build

O arquivo netlify.toml já contém estas configurações:
- Build command: npm run build
- Output directory: dist
- Install command: npm install

O redirecionamento de /api/* para a Function também está no netlify.toml. Se o painel mostrar campos próprios, use os mesmos valores.

### 5. Publique e confira

Faça um novo deploy a partir do repositório. Quando terminar, abra:

    https://SEU-SITE.netlify.app/api/health

Uma resposta saudavel inclui ok: true e storage: netlify-postgres ou external-postgres. Se aparecer erro de banco, confira a criação do banco e os logs de Functions no painel Netlify. Se a API responder, atualize a página com Ctrl+F5 e teste criar conta, login e registrar refeição.

## Executar localmente

Recomendado: Node.js 22.12 ou superior.

1. Na pasta do projeto, instale as dependências:

    npm install

2. Copie .env.example para .env e preencha as credenciais que pretende testar.
3. Inicie o servidor local:

    npm start

4. Abra http://localhost:3000.

No modo local, os dados ficam em data/scannatural.json, que é ignorado pelo Git. Na publicação Netlify, os dados ficam no PostgreSQL; os dois armazenamentos são separados. Cadastros locais antigos não são transferidos automaticamente para o banco Netlify.

## Recursos e limitações

- Registro de alimentos com cálculo de totais por refeição e dia.
- Metas nutricionais e histórico.
- Cadastro com código enviado por e-mail, login por senha e Google.
- Assistente e análise de fotos dependem de OPENAI_API_KEY.
- O webhook da Kirvano atualiza o status da conta; a Kirvano não é o banco do aplicativo.
- Configure SMTP, Google, OpenAI e Kirvano somente se for usar esses recursos.